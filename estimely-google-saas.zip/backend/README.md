
Backend (Node + Express)
Run:
npm install
npm start
