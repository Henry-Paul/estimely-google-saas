
Hybrid Google Architecture:
- PostgreSQL = system of record
- Google Sheets = transparent mirror
- Google Drive = user-owned files
