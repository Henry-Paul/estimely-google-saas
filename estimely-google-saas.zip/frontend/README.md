
Frontend (React + Vite)
Run:
npm install
npm run dev
